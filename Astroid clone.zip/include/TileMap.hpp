#ifndef TILEMAP_H
#define TILEMAP_H
/*
#include <Visibility.hpp>

class TileMap : public Visibility
{
    public:
        TileMap(std::string filename, sf::Vector2u tileSize, std::vector<int> tiles, unsigned int width, unsigned int height);
        ~TileMap();

        void Draw(sf::RenderWindow & window);
        int getTile(sf::Vector2f location);

        sf::Rect<float> GetBoundingRect() const;

    protected:
    sf::VertexArray _vertices;
    std::vector<int> _tiles;

    {
        0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3,
        0, 1, 0, 0, 2, 0, 3, 3, 3, 0, 1, 1, 1, 0, 0, 0,
        0, 1, 1, 0, 3, 3, 3, 0, 0, 0, 1, 1, 1, 2, 0, 0,
        0, 0, 1, 0, 3, 0, 2, 2, 0, 0, 1, 1, 1, 1, 2, 0,
        2, 0, 1, 0, 3, 0, 2, 2, 2, 0, 1, 1, 1, 1, 1, 1,
        0, 0, 1, 0, 3, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 1,
    };

    private:
};
*/
#endif // TILEMAP_H
