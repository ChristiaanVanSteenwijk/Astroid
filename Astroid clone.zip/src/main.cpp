#include "StateMachine.hpp"

int main()
{
	StateMachine Tdemo;
	Tdemo.run();
	return 0;
}
