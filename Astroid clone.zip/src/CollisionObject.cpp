#include "CollisionObject.hpp"
/*
enum CollisionObject : int
{
    Ship,
    Shot,
    None
};
*/
